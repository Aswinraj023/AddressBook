from flask import *
from werkzeug.utils import secure_filename
import sqlite3
UPLOAD_FOLDER = 'static/uploads/'
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024


@app.route("/")
def index():
    return render_template("index.html");

@app.route("/add")
def add():   
    return render_template("add.html")

@app.route("/savedetails",methods = ["POST","GET"])
def saveDetails():
    msg = "msg"
    if request.method == "POST":
        try:
            name = request.form["name"]
            email = request.form["email"]
            address = request.form["address"]
            number = request.form["number"]
            with sqlite3.connect("addressbook.db") as con:
                cur = con.cursor()   
                cur.execute("INSERT into Address (name, email, address, number) values (?,?,?,?)",(name,email,address,number))
                con.commit()
                msg = "Contact successfully Added"   
        except:
            con.rollback()
            msg = "We can not add Contact to the list"
        finally:
            return render_template("success.html",msg = msg)
            con.close()
@app.route("/edit/<id>")
def edit(id=0):
    con = sqlite3.connect("addressbook.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from Address where id=?",[id])   
    editrows = cur.fetchall()
    return render_template("edit.html",rows=editrows)
@app.route("/update",methods = ["POST"])
def update():
    if request.method == "POST":
        try:
            id = request.form["id"]
            name = request.form["name"]
            email = request.form["email"]
            address = request.form["address"]
            number = request.form["number"]
            with sqlite3.connect("addressbook.db") as con:
                cur = con.cursor()
                cur.execute("UPDATE Address SET name=?, email=?, address=?, number=? WHERE id=?", (name, email, address,number, id))
                con.commit()
                msg = "Contact successfully updated"
        except:
            con.rollback()
            msg = "Cannot update Contact to the list"
        finally:
            return render_template("success.html",msg = msg)
            con.close()
@app.route("/view")
def view():
    con = sqlite3.connect("addressbook.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from Address")   
    rows = cur.fetchall()
    return render_template("view.html",rows = rows)

@app.route("/delete")
def delete():
    return render_template("delete.html")

@app.route("/deleterecord",methods = ["POST"])   
def deleterecord():
    id = request.form["id"]
    with sqlite3.connect("addressbook.db") as con:
        try:
            cur = con.cursor()
            cur.execute("DELETE from Address WHERE id=?",[id])
            msg = "Contact successfully deleted"   
        except:
            msg = "can't be deleted"
        finally:
            return render_template("delete_record.html",msg = msg)

@app.route("/deleteid/<id>",methods = ["GET"])
def deleteid(id=0):
    with sqlite3.connect("addressbook.db") as con:
        try:
            cur = con.cursor()
            cur.execute("DELETE from Address WHERE id=?",[id])
            msg = "Contact successfully deleted"
        except:
            msg = "can't be deleted"
        finally:
            return render_template("delete_record.html",msg = msg)

@app.route("/upload")
def upload():
   return render_template("upload.html")
	
@app.route("/uploader/<id>", methods = ["GET", "POST"])
def uploader(id=0):
    if request.method == "POST":
       f = request.files["file"]
       f.save(secure_filename(f.filename))
       msg = "file uploaded successfully"
       return render_template("view.html",msg)
		
if __name__ == "__main__":
    app.run(debug = True)  
